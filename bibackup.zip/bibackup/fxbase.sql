-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: fxbase
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vc_ali_bank`
--

DROP TABLE IF EXISTS `vc_ali_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_ali_bank` (
  `sys_id` int(11) DEFAULT NULL,
  `ali_Account` varchar(100) DEFAULT NULL COMMENT '支付宝账户',
  `real_name` varchar(100) DEFAULT NULL COMMENT '支付宝真实姓名',
  `card_account` varchar(100) DEFAULT NULL COMMENT '银行卡账号',
  `bank_name` varchar(100) DEFAULT NULL COMMENT '持卡人姓名',
  `id_Card` varchar(100) DEFAULT NULL COMMENT '身份证号码',
  `bank_type` varchar(20) DEFAULT '-1' COMMENT '选择开户行',
  `province` varchar(100) DEFAULT NULL COMMENT '开户行所在省份',
  `city` varchar(100) DEFAULT NULL COMMENT '开户行所在城市',
  `bank_password` varchar(100) DEFAULT NULL,
  `bank_branch` varchar(100) DEFAULT NULL,
  `aliBind` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_channel`
--

DROP TABLE IF EXISTS `vc_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_channel` (
  `id` int(11) NOT NULL,
  `channel` varchar(100) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_code`
--

DROP TABLE IF EXISTS `vc_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_code_log`
--

DROP TABLE IF EXISTS `vc_code_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_code_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `tx_count` varchar(100) DEFAULT NULL,
  `yl_count` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `info` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_comment`
--

DROP TABLE IF EXISTS `vc_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL COMMENT '标题',
  `comment` varchar(500) DEFAULT NULL COMMENT '公告内容',
  `add_time` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_countlog`
--

DROP TABLE IF EXISTS `vc_countlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_countlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tx_count` varchar(100) DEFAULT NULL,
  `yl_count` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `info` varchar(500) DEFAULT NULL,
  `check_time` datetime DEFAULT NULL,
  `channel` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=657710 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_day`
--

DROP TABLE IF EXISTS `vc_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=628 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_domain`
--

DROP TABLE IF EXISTS `vc_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_parm` varchar(300) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `android_url` varchar(100) DEFAULT NULL,
  `ios_url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_fenx_bang`
--

DROP TABLE IF EXISTS `vc_fenx_bang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_fenx_bang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invitedrid` int(11) DEFAULT NULL,
  `invitedName` varchar(100) DEFAULT NULL,
  `invite_num` int(11) DEFAULT '0' COMMENT 'é‚€è¯·æ€»äººæ•°',
  `shou_rechange_num` int(11) DEFAULT '0' COMMENT 'å—é‚€å……å€¼äººæ•°',
  `shou_rechange_money` int(11) DEFAULT '0' COMMENT 'å—é‚€å……å€¼æ€»é¢',
  `jin_yaoqing_num` varchar(100) DEFAULT '0' COMMENT 'ä»Šæ—¥é‚€è¯·äººæ•°',
  `jin_rechange_num` varchar(100) DEFAULT '0' COMMENT 'ä»Šæ—¥å……å€¼äººæ•°',
  `jin_shou_rechange_num` int(11) DEFAULT '0' COMMENT 'ä»Šæ—¥å—é‚€å……å€¼é¢',
  `day_duty_num` varchar(100) DEFAULT NULL COMMENT 'ä»Šæ—¥å—é‚€ä¸‹æ³¨é¢',
  `day_tax_num` varchar(100) DEFAULT NULL COMMENT 'ä»Šæ—¥ä¸‹æ³¨å¥–',
  `all_tax_num` varchar(100) DEFAULT NULL COMMENT 'æ€»ä¸‹æ³¨å¥–',
  `all_duty_num` varchar(100) DEFAULT NULL COMMENT 'æ€»å—é‚€ä¸‹æ³¨é¢',
  `update_time` datetime DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1710071 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_fenx_count`
--

DROP TABLE IF EXISTS `vc_fenx_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_fenx_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fenx_num` int(11) DEFAULT '0' COMMENT 'åˆ†äº«æ€»äººæ•°',
  `shou_num` int(11) DEFAULT '0' COMMENT 'å—é‚€æ€»äººæ•°',
  `jin_fen_num` int(11) DEFAULT NULL COMMENT 'ä»Šæ—¥åˆ†äº«äººæ•°',
  `jin_shou_num` int(11) DEFAULT '0' COMMENT 'ä»Šæ—¥å—é‚€äººæ•°',
  `shou_rechange_num` int(11) DEFAULT '0' COMMENT 'å—é‚€å……å€¼æ€»é¢',
  `shou_duty_num` varchar(100) DEFAULT '0' COMMENT 'å—é‚€ä¸‹æ³¨æ€»é¢',
  `shou_tax_num` varchar(100) DEFAULT NULL COMMENT 'å—é‚€ä¸‹æ³¨æ€»å¥–',
  `jin_shou_rechange_num` int(11) DEFAULT '0' COMMENT 'ä»Šæ—¥å—é‚€å……å€¼é¢',
  `jin_shou_duty_num` varchar(100) DEFAULT '0' COMMENT 'ä»Šæ—¥å—é‚€ä¸‹æ³¨',
  `jin_shou_tax_num` varchar(100) DEFAULT NULL COMMENT 'ä»Šæ—¥å—é‚€ä¸‹æ³¨å¥–',
  `day_shou_rechange_num` int(11) DEFAULT '0' COMMENT 'éžä»Šæ—¥å—é‚€å……å€¼é¢',
  `day_shou_duty_num` varchar(100) DEFAULT '0' COMMENT 'éžä»Šæ—¥å—é‚€ä¸‹æ³¨é¢',
  `day_shou_tax_num` varchar(100) DEFAULT NULL COMMENT 'éžä»Šæ—¥å—é‚€ä¸‹æ³¨å¥–',
  `day_tax_num` varchar(100) DEFAULT NULL COMMENT 'ä»Šæ—¥é¢†å¥–',
  `yue_num` varchar(100) DEFAULT NULL COMMENT 'å‰©ä½™æ€»å¥–',
  `create_time` date DEFAULT NULL,
  `jin_cz_count` int(11) DEFAULT '0' COMMENT 'ä»Šæ—¥é¦–ä»˜äººæ•°',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23849 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_fenx_zcjb`
--

DROP TABLE IF EXISTS `vc_fenx_zcjb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_fenx_zcjb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fenx_num` int(11) DEFAULT '0' COMMENT '分享总人数',
  `shou_num` int(11) DEFAULT '0' COMMENT '受邀总人数',
  `jin_fen_num` int(11) DEFAULT NULL COMMENT '今日分享人数',
  `jin_shou_num` int(11) DEFAULT '0' COMMENT '今日受邀人数',
  `shou_rechange_num` int(11) DEFAULT '0' COMMENT '受邀充值总额',
  `shou_duty_num` varchar(100) DEFAULT '0' COMMENT '受邀下注总额',
  `shou_tax_num` varchar(100) DEFAULT NULL COMMENT '受邀下注总奖',
  `jin_shou_rechange_num` int(11) DEFAULT '0' COMMENT '今日受邀充值额',
  `jin_shou_duty_num` varchar(100) DEFAULT '0' COMMENT '今日受邀下注',
  `jin_shou_tax_num` varchar(100) DEFAULT NULL COMMENT '今日受邀下注奖',
  `day_shou_rechange_num` int(11) DEFAULT '0' COMMENT '非今日受邀充值额',
  `day_shou_duty_num` varchar(100) DEFAULT '0' COMMENT '非今日受邀下注额',
  `day_shou_tax_num` varchar(100) DEFAULT NULL COMMENT '非今日受邀下注奖',
  `day_tax_num` varchar(100) DEFAULT NULL COMMENT '今日领奖',
  `yue_num` varchar(100) DEFAULT NULL COMMENT '剩余总奖',
  `create_time` date DEFAULT NULL,
  `jin_cz_count` int(11) DEFAULT '0' COMMENT 'ä»Šæ—¥é¦–ä»˜äººæ•°',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14842 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_gamenum_log`
--

DROP TABLE IF EXISTS `vc_gamenum_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_gamenum_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` int(11) DEFAULT NULL,
  `game_num` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `info` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_income`
--

DROP TABLE IF EXISTS `vc_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_income` (
  `income_id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` int(11) DEFAULT NULL,
  `income_number` decimal(12,2) DEFAULT NULL,
  `game_id` int(11) DEFAULT NULL,
  `agent_income` varchar(100) DEFAULT NULL COMMENT '税收',
  `create_time` datetime DEFAULT NULL,
  `game_name` varchar(100) DEFAULT NULL,
  `game_type` int(2) DEFAULT NULL,
  `channel_name` varchar(100) DEFAULT NULL COMMENT '渠道',
  PRIMARY KEY (`income_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_invitedrid_num`
--

DROP TABLE IF EXISTS `vc_invitedrid_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_invitedrid_num` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `invitedrid` int(11) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `info` varchar(1000) DEFAULT NULL,
  `week_info` varchar(100) DEFAULT NULL,
  `tax_num` varchar(100) DEFAULT NULL,
  `invitedName` varchar(100) DEFAULT NULL,
  `ridName` varchar(100) DEFAULT NULL,
  `ridtime` int(11) DEFAULT NULL,
  `req_rid_num` varchar(100) DEFAULT NULL COMMENT 'å—é‚€å……å€¼æ€»é¢',
  `req_total_pay` varchar(100) DEFAULT NULL COMMENT 'é‚€è¯·å……å€¼æ€»é¢',
  `jin_rin_num` varchar(100) DEFAULT NULL,
  `jin_rid_count` varchar(100) DEFAULT NULL,
  `jin_total_num` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`) USING HASH
) ENGINE=MyISAM AUTO_INCREMENT=41822002 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log`
--

DROP TABLE IF EXISTS `vc_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT '',
  `login_time` datetime DEFAULT NULL,
  `login_ip` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=882 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log_ip`
--

DROP TABLE IF EXISTS `vc_log_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_time` datetime DEFAULT NULL,
  `login_ip` varchar(255) DEFAULT '',
  `phone` varchar(155) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=242 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log_money`
--

DROP TABLE IF EXISTS `vc_log_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` varchar(255) DEFAULT '',
  `login_time` date DEFAULT NULL,
  `all_balance` varchar(255) DEFAULT NULL,
  `tax_num` varchar(255) DEFAULT '',
  `login_ip` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11771 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_pomotion`
--

DROP TABLE IF EXISTS `vc_pomotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_pomotion` (
  `promotion_id` int(11) NOT NULL AUTO_INCREMENT,
  `code_id` int(11) DEFAULT NULL,
  `promotion_address` varchar(100) DEFAULT NULL,
  `promotion_name` varchar(100) DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_qrcode`
--

DROP TABLE IF EXISTS `vc_qrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_qrcode` (
  `code_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) DEFAULT NULL,
  `spread_url` varchar(500) DEFAULT NULL,
  `min_pic` varchar(500) DEFAULT NULL,
  `max_pic` varchar(500) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_rid`
--

DROP TABLE IF EXISTS `vc_rid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_rid` (
  `uid` int(11) NOT NULL,
  `invitedrid` int(11) DEFAULT NULL,
  `invitedtime` int(11) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  `balance_give` int(11) DEFAULT '0',
  `status` int(2) DEFAULT '0',
  `channel` int(11) DEFAULT '0' COMMENT 'æ¸ é“å·',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `rid` (`rid`),
  KEY `invitedtime` (`invitedtime`) USING BTREE,
  KEY `invitedrid` (`invitedrid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_rid_code`
--

DROP TABLE IF EXISTS `vc_rid_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_rid_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`) USING BTREE,
  KEY `url` (`url`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29735 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_rid_user`
--

DROP TABLE IF EXISTS `vc_rid_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_rid_user` (
  `rid` int(11) NOT NULL,
  `sys_user` varchar(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `all_balance` varchar(100) DEFAULT '0',
  `game_num` varchar(100) DEFAULT NULL,
  `state` int(2) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_setting`
--

DROP TABLE IF EXISTS `vc_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_type` int(11) DEFAULT '1',
  `key_name` varchar(255) DEFAULT '',
  `key_url` varchar(255) DEFAULT '',
  `order_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_statistics`
--

DROP TABLE IF EXISTS `vc_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_statistics` (
  `statistics_id` int(11) NOT NULL AUTO_INCREMENT,
  `charge_number` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `duty_number` char(100) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `reflect_number` int(11) DEFAULT NULL,
  `register_number` int(11) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`statistics_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_sys`
--

DROP TABLE IF EXISTS `vc_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_user` varchar(20) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `sys_password` varchar(100) DEFAULT NULL,
  `sys_level` int(4) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(30) DEFAULT NULL,
  `privilege` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `gent_nick` varchar(100) DEFAULT NULL,
  `proportions` varchar(100) DEFAULT NULL,
  `is_ip` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `balance` varchar(100) DEFAULT '0',
  `login_time` datetime DEFAULT NULL,
  `info` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `creat_time` datetime DEFAULT NULL,
  `all_balance` varchar(100) DEFAULT '0',
  `rid` int(11) DEFAULT '0',
  `tk_balance` varchar(100) DEFAULT NULL,
  `game_num` varchar(100) DEFAULT NULL,
  `state` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44003 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_template`
--

DROP TABLE IF EXISTS `vc_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_template` (
  `template_Id` int(11) NOT NULL AUTO_INCREMENT,
  `template_title` varchar(100) DEFAULT NULL,
  `template_introduce` varchar(100) DEFAULT NULL,
  `template_url` varchar(100) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`template_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_week`
--

DROP TABLE IF EXISTS `vc_week`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_week` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `info` varchar(1000) DEFAULT NULL,
  `week_info` varchar(100) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `tax_num` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2114 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 19:18:20
