-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: bi
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administratorrecord`
--

DROP TABLE IF EXISTS `administratorrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administratorrecord` (
  `recordid` int(11) NOT NULL AUTO_INCREMENT,
  `adminid` int(11) NOT NULL COMMENT '管理员id',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '备注',
  `describe` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '描述',
  `time` int(11) NOT NULL COMMENT '时间',
  `type` int(11) NOT NULL COMMENT '操作类型',
  `rid` int(11) DEFAULT NULL COMMENT '对象id',
  `ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '操作ip',
  PRIMARY KEY (`recordid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agency_admin_money`
--

DROP TABLE IF EXISTS `agency_admin_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agency_admin_money` (
  `recordid` int(11) NOT NULL AUTO_INCREMENT COMMENT '操作员',
  `doadmin` varchar(255) DEFAULT NULL,
  `money` double NOT NULL,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`recordid`,`money`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `banner_info`
--

DROP TABLE IF EXISTS `banner_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner_info` (
  `rank` int(4) NOT NULL,
  `banner` varchar(255) NOT NULL DEFAULT '',
  `selected` varchar(255) NOT NULL DEFAULT '',
  `unselected` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `banner_zcjb_info`
--

DROP TABLE IF EXISTS `banner_zcjb_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner_zcjb_info` (
  `rank` int(4) NOT NULL,
  `banner` varchar(255) NOT NULL DEFAULT '',
  `selected` varchar(255) NOT NULL DEFAULT '',
  `unselected` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `black_bank_account`
--

DROP TABLE IF EXISTS `black_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `black_bank_account` (
  `bankAccount` varchar(64) NOT NULL DEFAULT '',
  `name` varchar(25) NOT NULL DEFAULT '',
  `putInTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bankAccount`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `browse`
--

DROP TABLE IF EXISTS `browse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `browse` (
  `generalizeid` int(11) NOT NULL AUTO_INCREMENT,
  `generalizepid` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `browseip` varchar(20) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1是安卓，2是IOS',
  PRIMARY KEY (`generalizeid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cashexport`
--

DROP TABLE IF EXISTS `cashexport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashexport` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单号',
  `rid` int(11) NOT NULL DEFAULT '0' COMMENT '游戏id',
  `accounttype` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '账户类型 1 支付宝 2 银行卡',
  `account` varchar(1024) NOT NULL DEFAULT '' COMMENT '兑换账户',
  `realname` varchar(1024) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `cashask` int(11) NOT NULL DEFAULT '0' COMMENT '申请金额',
  `cashfee` tinyint(4) NOT NULL DEFAULT '0' COMMENT '费率',
  `cashexport` double(11,0) NOT NULL DEFAULT '0' COMMENT '实际出款金额',
  `states` tinyint(4) NOT NULL DEFAULT '0' COMMENT '订单状态 0 审核中 1预出款 2已成功 3已退回 4 已拒绝',
  `canbesign` tinyint(4) NOT NULL DEFAULT '0' COMMENT '能否被标记 0 为能 1位不能',
  `operator` varchar(32) NOT NULL DEFAULT '' COMMENT '操作员',
  `operatedesc` varchar(160) NOT NULL DEFAULT '' COMMENT '操作员备注',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '申请时间',
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据更新时间',
  `bankname` varchar(256) NOT NULL DEFAULT '',
  `banktypename` varchar(256) NOT NULL DEFAULT '',
  `operatedescag` varchar(256) NOT NULL DEFAULT '',
  `submitorder` varchar(225) DEFAULT NULL,
  `sysremark` varchar(225) DEFAULT NULL,
  `issys` int(4) NOT NULL DEFAULT '0',
  `channel` int(9) NOT NULL DEFAULT '0',
  `isfirst` int(2) NOT NULL DEFAULT '0',
  `providerid` int(11) DEFAULT NULL,
  `gamerolename` varchar(255) DEFAULT NULL,
  `isadmin` int(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orderid`),
  KEY `createtime` (`createtime`),
  KEY `updatetime` (`updatetime`),
  KEY `states` (`states`),
  KEY `channel` (`channel`),
  KEY `operator` (`operator`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10028 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cashexport_grade`
--

DROP TABLE IF EXISTS `cashexport_grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashexport_grade` (
  `orderid` int(11) NOT NULL,
  `thistime_deposit` double DEFAULT NULL COMMENT '本次充值',
  `thistime_activity` double DEFAULT NULL COMMENT '本次获得活动奖励',
  `thistime_tixian` double DEFAULT NULL COMMENT '本次提现',
  `thistime_dama` int(11) DEFAULT NULL COMMENT '本次打码',
  `thistime_beforecoin` double(11,0) DEFAULT NULL,
  `thistime_coin` int(11) DEFAULT NULL COMMENT '本次提现后金币剩余',
  `thistime_channel` varchar(255) DEFAULT NULL,
  `thistime_ip` varchar(255) DEFAULT NULL,
  `today_deposit` double(255,0) DEFAULT NULL,
  `today_activity` double(255,0) DEFAULT NULL,
  `today_tixian` double(255,0) DEFAULT NULL,
  `today_beforecoin` double(11,0) DEFAULT NULL,
  `today_dama` double(255,0) DEFAULT NULL,
  `ago_deposit` double(255,0) DEFAULT NULL,
  `ago_activity` double(255,0) DEFAULT NULL,
  `ago_tixian` double(255,0) DEFAULT NULL,
  `ago_dama` int(255) DEFAULT NULL,
  `score` double(255,0) DEFAULT NULL,
  `grade` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clientrid`
--

DROP TABLE IF EXISTS `clientrid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientrid` (
  `rid` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `continuepay_channel_data`
--

DROP TABLE IF EXISTS `continuepay_channel_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continuepay_channel_data` (
  `timeStamp` int(11) NOT NULL,
  `channel` int(11) NOT NULL,
  `firstPayPersons` int(11) NOT NULL DEFAULT '0',
  `afterFirstPayRateDay2` double(10,4) DEFAULT '0.0000',
  `afterFirstPayRateDay3` double(10,4) DEFAULT '0.0000',
  `afterFirstPayRateDay7` double(10,4) DEFAULT '0.0000',
  `afterFirstPayRateDay15` double(10,4) DEFAULT '0.0000',
  `afterFirstPayRateDay30` double(10,4) DEFAULT '0.0000',
  `afterFirstPayRateDay60` double(10,4) DEFAULT '0.0000',
  `state` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000',
  PRIMARY KEY (`timeStamp`,`channel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_agencypay_distribution`
--

DROP TABLE IF EXISTS `data_agencypay_distribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_agencypay_distribution` (
  `time` varchar(255) DEFAULT NULL,
  `ceng1` int(255) DEFAULT NULL,
  `ceng2` int(255) DEFAULT NULL,
  `ceng3` int(255) DEFAULT NULL,
  `ceng4` int(255) DEFAULT NULL,
  `ceng5` int(255) DEFAULT NULL,
  `ceng6` int(255) DEFAULT NULL,
  `ceng7` int(255) DEFAULT NULL,
  `ceng8` int(255) DEFAULT NULL,
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_daylive`
--

DROP TABLE IF EXISTS `data_daylive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_daylive` (
  `time` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1是游戏渠道,2是大推广',
  `channel` int(11) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `daylive` int(11) DEFAULT NULL COMMENT '日活',
  `register` int(11) DEFAULT NULL COMMENT '注册',
  `highplay` int(11) DEFAULT NULL COMMENT '最高在玩',
  `registerkeep2` int(11) DEFAULT NULL COMMENT '注册第二天',
  `registerkeep3` int(11) DEFAULT NULL,
  `registerkeep7` int(11) DEFAULT NULL,
  `registerkeep15` int(11) DEFAULT NULL,
  `registerkeep30` int(11) DEFAULT NULL,
  `loginkeep2` int(11) DEFAULT NULL,
  `loginkeep3` int(11) DEFAULT NULL,
  `loginkeep7` int(11) DEFAULT NULL,
  `loginkeep15` int(11) DEFAULT NULL,
  `loginkeep30` int(11) DEFAULT NULL,
  KEY `channel` (`channel`),
  KEY `bigchannel` (`bigchannel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_firstpay_keep`
--

DROP TABLE IF EXISTS `data_firstpay_keep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_firstpay_keep` (
  `time` varchar(255) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `firstpay` int(255) DEFAULT NULL,
  `keep2` int(255) DEFAULT NULL,
  `keep3` int(255) DEFAULT NULL,
  `keep7` int(255) DEFAULT NULL,
  `keep15` int(255) DEFAULT NULL,
  `keep30` int(255) DEFAULT NULL,
  `keep60` int(255) DEFAULT NULL,
  `keep90` int(255) DEFAULT NULL,
  `keep120` int(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_loginip_rank`
--

DROP TABLE IF EXISTS `data_loginip_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_loginip_rank` (
  `time` varchar(10) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_palyernum`
--

DROP TABLE IF EXISTS `data_palyernum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_palyernum` (
  `timeday` varchar(255) NOT NULL,
  `palyernum` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_pay_continue`
--

DROP TABLE IF EXISTS `data_pay_continue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_pay_continue` (
  `time` varchar(255) NOT NULL,
  `day1` int(11) DEFAULT NULL,
  `day2` int(11) DEFAULT NULL,
  `day3` int(11) DEFAULT NULL,
  `day7` int(11) DEFAULT NULL,
  `day15` int(11) DEFAULT NULL,
  `day30` int(11) DEFAULT NULL,
  PRIMARY KEY (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_pay_distribute`
--

DROP TABLE IF EXISTS `data_pay_distribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_pay_distribute` (
  `time` varchar(255) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `daylive` int(255) DEFAULT NULL,
  `allpay` double(10,2) DEFAULT NULL,
  `zcmdaili` double(10,2) DEFAULT NULL,
  `zcjbdaili` double(10,2) DEFAULT NULL,
  `onlinepay` double(10,2) DEFAULT NULL,
  `offlinepay` double(10,2) DEFAULT NULL,
  `allpaypalyer` int(10) DEFAULT NULL,
  `zcmdailipalyer` int(10) DEFAULT NULL,
  `zcjbdailipalyer` int(10) DEFAULT NULL,
  `onlinepaypalyer` int(10) DEFAULT NULL,
  `offlinepaypalyer` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_pay_survey`
--

DROP TABLE IF EXISTS `data_pay_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_pay_survey` (
  `time` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `channel` int(255) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `dayactive` int(11) DEFAULT NULL COMMENT '日活跃',
  `allpay` double DEFAULT NULL COMMENT '总支付',
  `payplayer` int(255) DEFAULT NULL,
  `firstplayer` int(11) DEFAULT NULL COMMENT '首付人数',
  `registerfirst` int(255) DEFAULT NULL COMMENT '注册并首付',
  KEY `channel` (`channel`),
  KEY `bigchannel` (`bigchannel`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_register`
--

DROP TABLE IF EXISTS `data_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_register` (
  `time` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1是游戏渠道,2是大推广',
  `channel` int(11) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `register` int(11) DEFAULT NULL,
  `register2` int(255) DEFAULT NULL,
  `register3` int(255) DEFAULT NULL,
  `register4` int(255) DEFAULT NULL,
  `register5` int(255) DEFAULT NULL,
  `register6` int(255) DEFAULT NULL,
  `register7` int(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dianka_info`
--

DROP TABLE IF EXISTS `dianka_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dianka_info` (
  `dianKaType` varchar(12) NOT NULL,
  `dianKaName` varchar(128) CHARACTER SET utf8 DEFAULT '',
  `picurl` varchar(128) DEFAULT '',
  PRIMARY KEY (`dianKaType`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `download`
--

DROP TABLE IF EXISTS `download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `download` (
  `downloadid` int(11) NOT NULL AUTO_INCREMENT,
  `downloadip` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `generalizepid` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`downloadid`),
  KEY `time` (`time`),
  KEY `generalizepid` (`generalizepid`)
) ENGINE=MyISAM AUTO_INCREMENT=3163644 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `downloadload`
--

DROP TABLE IF EXISTS `downloadload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `downloadload` (
  `rid` int(11) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `generalizeid` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `forwarding_agency`
--

DROP TABLE IF EXISTS `forwarding_agency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forwarding_agency` (
  `recordid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `money` double NOT NULL,
  `time` datetime NOT NULL,
  `agencyid` int(11) DEFAULT NULL COMMENT '代理id',
  `status` int(11) DEFAULT '1' COMMENT '1是失败0是成功',
  `channel` int(6) NOT NULL DEFAULT '0',
  `terrace` int(1) NOT NULL DEFAULT '2',
  `indicateid` int(11) DEFAULT NULL COMMENT '代理充值ID防止重复',
  PRIMARY KEY (`recordid`),
  KEY `rid` (`rid`),
  KEY `time` (`time`),
  KEY `status` (`status`),
  KEY `indicateid` (`indicateid`) USING HASH
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `game_allchannel`
--

DROP TABLE IF EXISTS `game_allchannel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_allchannel` (
  `channel` int(11) NOT NULL,
  `channelname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gamecoinrank`
--

DROP TABLE IF EXISTS `gamecoinrank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamecoinrank` (
  `rid` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '是几天的合集',
  `reason` int(255) NOT NULL COMMENT '游戏类型',
  `coin` double(255,2) DEFAULT NULL COMMENT '总输赢',
  `rolename` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '角色名称',
  `latstime` int(11) DEFAULT NULL COMMENT '最后更新时间',
  `rank` int(11) DEFAULT NULL,
  PRIMARY KEY (`rid`,`type`,`reason`),
  KEY `rid` (`rid`),
  KEY `type` (`type`),
  KEY `reason` (`reason`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gameuserremark`
--

DROP TABLE IF EXISTS `gameuserremark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gameuserremark` (
  `rid` int(11) NOT NULL,
  `remark` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`rid`),
  KEY `rid` (`rid`) USING HASH
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `generalize`
--

DROP TABLE IF EXISTS `generalize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generalize` (
  `generalizeid` int(11) NOT NULL AUTO_INCREMENT,
  `generalizepid` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `androidurl` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `iosurl` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `generalizename` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `www` varchar(255) DEFAULT NULL COMMENT '推广网站备注',
  `channle` int(11) DEFAULT NULL,
  `isdaili` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`generalizeid`),
  KEY `generalizepid` (`generalizepid`),
  KEY `generalizename` (`generalizename`),
  KEY `www` (`www`)
) ENGINE=MyISAM AUTO_INCREMENT=2008679 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `generalize_keep`
--

DROP TABLE IF EXISTS `generalize_keep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generalize_keep` (
  `generalizepid` varchar(20) NOT NULL,
  `time` varchar(255) NOT NULL,
  `pay` int(11) DEFAULT NULL,
  `keep1` int(11) DEFAULT NULL,
  `keep2` int(11) DEFAULT NULL,
  `keep3` int(11) DEFAULT NULL,
  `keep7` int(11) DEFAULT NULL,
  `keep15` int(11) DEFAULT NULL,
  `keep30` int(11) DEFAULT NULL,
  `keep60` int(11) DEFAULT NULL,
  `cost` double(10,2) DEFAULT NULL COMMENT '成本',
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`generalizepid`,`time`),
  KEY `bigchannel` (`bigchannel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `generalize_tax`
--

DROP TABLE IF EXISTS `generalize_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generalize_tax` (
  `time` varchar(255) NOT NULL,
  `generalizepid` varchar(255) NOT NULL,
  `cost` double(10,2) DEFAULT NULL,
  `firstpaynum` int(11) DEFAULT NULL,
  `tax1` double DEFAULT NULL,
  `tax2` double(255,2) DEFAULT NULL,
  `tax3` double(255,2) DEFAULT NULL,
  `tax4` double(255,2) DEFAULT NULL,
  `tax5` double(255,2) DEFAULT NULL,
  `tax6` double(255,2) DEFAULT NULL,
  `tax7` double(255,2) DEFAULT NULL,
  `tax15` double(255,2) DEFAULT NULL,
  `tax30` double(255,2) DEFAULT NULL,
  `tax60` double(255,2) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `register` int(11) DEFAULT NULL COMMENT '注册',
  PRIMARY KEY (`time`,`generalizepid`),
  KEY `bigchannel` (`bigchannel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `horseracelamp`
--

DROP TABLE IF EXISTS `horseracelamp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horseracelamp` (
  `horseracelampid` int(11) NOT NULL AUTO_INCREMENT,
  `createtime` int(11) DEFAULT NULL,
  `updatatime` int(11) DEFAULT NULL,
  `adminid` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '跑马灯类型',
  `location` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '执行位置',
  `interval` int(11) DEFAULT NULL COMMENT '间隔',
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '内容',
  `rank` int(11) DEFAULT NULL COMMENT '优先级',
  `starttime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT '状态',
  `downstate` int(4) NOT NULL DEFAULT '0',
  `hide` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`horseracelampid`)
) ENGINE=MyISAM AUTO_INCREMENT=330 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kfrecord`
--

DROP TABLE IF EXISTS `kfrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kfrecord` (
  `kfrecordid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL COMMENT '玩家ID',
  `stime` int(11) NOT NULL COMMENT '玩家发送时间',
  `mess` varchar(700) CHARACTER SET utf8 NOT NULL COMMENT '消息内容',
  `adminid` int(11) DEFAULT NULL COMMENT '操作员Id',
  `status` int(11) NOT NULL COMMENT '0是未处理，1是已处理，2是一忽略',
  `replymess` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '回复的消息',
  `etime` int(11) DEFAULT NULL COMMENT '回复的时间',
  `channel` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kfrecordid`),
  KEY `rid` (`rid`),
  KEY `channel` (`channel`),
  KEY `stime` (`stime`),
  KEY `etime` (`etime`)
) ENGINE=MyISAM AUTO_INCREMENT=59646 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `level_info`
--

DROP TABLE IF EXISTS `level_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level_info` (
  `userLevel` int(4) NOT NULL DEFAULT '0',
  `userLevelName` varchar(40) CHARACTER SET utf8 DEFAULT '' COMMENT '用户层级名称',
  `userLevelDesc` varchar(128) CHARACTER SET utf8 DEFAULT '' COMMENT '用户层级描述，默认空字符串',
  `onlinePayMin` int(11) DEFAULT NULL,
  `onlinePayMax` int(11) DEFAULT NULL COMMENT '线上总充值范围',
  `onlinePayTimesMin` int(11) DEFAULT NULL,
  `onlinePayTimesMax` int(11) DEFAULT NULL COMMENT '线上总充值次数范围',
  `offlinePayMin` int(11) DEFAULT NULL COMMENT '线下总充值，范围',
  `offlinePayMax` int(11) DEFAULT NULL,
  `offlinePayTimesMin` int(11) DEFAULT NULL,
  `offlinePayTimesMax` int(11) DEFAULT NULL COMMENT '线下总充值次数范围',
  `totalChipInMin` int(11) DEFAULT NULL COMMENT '总打码量范围',
  `totalChipInMax` int(11) DEFAULT NULL,
  `totalCashExportMin` int(11) DEFAULT NULL COMMENT '总提现范围',
  `totalCashExportMax` int(11) DEFAULT NULL,
  `totalCashExportTimesMin` int(11) DEFAULT NULL COMMENT '总提现次数范围',
  `totalCashExportTimesMax` int(11) DEFAULT NULL,
  `mostPayOneTimeMin` int(11) DEFAULT NULL COMMENT '单次最大提现范围',
  `mostPayOneTimeMax` int(11) DEFAULT NULL,
  `onlineTimeMin` int(11) DEFAULT NULL,
  `onlineTimeMax` int(11) DEFAULT NULL,
  `createTimeMin` int(11) DEFAULT NULL,
  `createTimeMax` int(11) DEFAULT NULL,
  `playedTimeMin` int(11) DEFAULT NULL,
  `playedTimeMax` int(11) DEFAULT NULL,
  `playedGameNumMin` int(11) DEFAULT NULL,
  `playedGameNumMax` int(11) DEFAULT NULL,
  `updateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`userLevel`),
  KEY `userLevel` (`userLevel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `merchant_set_info`
--

DROP TABLE IF EXISTS `merchant_set_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchant_set_info` (
  `channel` int(11) NOT NULL,
  `channelId` int(11) NOT NULL,
  `payType` int(11) NOT NULL,
  `userLevels` varchar(255) NOT NULL DEFAULT '[]',
  `useState` int(4) NOT NULL DEFAULT '0' COMMENT '0为启用 1为普通停用 2为支付停用',
  PRIMARY KEY (`channel`,`channelId`,`payType`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `merchant_type_paylevels`
--

DROP TABLE IF EXISTS `merchant_type_paylevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchant_type_paylevels` (
  `channelId` varchar(255) NOT NULL,
  `payType` varchar(255) NOT NULL,
  `paylevels` varchar(255) NOT NULL DEFAULT '[]',
  `useState` int(4) NOT NULL DEFAULT '0',
  `lowerlimit` int(11) NOT NULL DEFAULT '0',
  `upperlimit` int(11) NOT NULL,
  `interval` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`channelId`,`payType`),
  KEY `useStateOfMerchantLevels` (`useState`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `monster_vip`
--

DROP TABLE IF EXISTS `monster_vip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monster_vip` (
  `account` varchar(112) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `payFrom` int(11) NOT NULL DEFAULT '0',
  `vipRank` int(4) NOT NULL DEFAULT '0',
  `des` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `name`
--

DROP TABLE IF EXISTS `name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `name` (
  `nameid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`nameid`)
) ENGINE=MyISAM AUTO_INCREMENT=19843 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `new_generalize`
--

DROP TABLE IF EXISTS `new_generalize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_generalize` (
  `newgeneralizeid` int(255) NOT NULL AUTO_INCREMENT,
  `generalizepid` varchar(255) DEFAULT NULL,
  `androidurl` varchar(255) DEFAULT NULL,
  `appleurl` varchar(255) DEFAULT NULL,
  `www` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `iscount` int(2) NOT NULL DEFAULT '0',
  `cost` double(10,2) NOT NULL DEFAULT '0.00',
  `analyze` varchar(255) DEFAULT NULL,
  `bigchannel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci DEFAULT NULL,
  PRIMARY KEY (`newgeneralizeid`)
) ENGINE=MyISAM AUTO_INCREMENT=432 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `new_generalize_rid`
--

DROP TABLE IF EXISTS `new_generalize_rid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_generalize_rid` (
  `rid` int(11) NOT NULL,
  `generalizepid` varchar(255) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`rid`),
  KEY `generalizepid` (`generalizepid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offline_pay`
--

DROP TABLE IF EXISTS `offline_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_pay` (
  `offlinepayid` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) CHARACTER SET utf8 NOT NULL,
  `status` int(11) DEFAULT NULL,
  `adminid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `remark` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 NOT NULL,
  `order` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `typenum` int(11) DEFAULT NULL,
  `channel` int(9) DEFAULT NULL,
  PRIMARY KEY (`offlinepayid`),
  KEY `time` (`time`),
  KEY `rid` (`rid`),
  KEY `typenum` (`typenum`)
) ENGINE=MyISAM AUTO_INCREMENT=137009 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_api`
--

DROP TABLE IF EXISTS `pay_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_api` (
  `pay_api_id` int(4) NOT NULL,
  `payAPI` varchar(255) NOT NULL,
  PRIMARY KEY (`pay_api_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_channel`
--

DROP TABLE IF EXISTS `pay_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_channel` (
  `channel` int(11) NOT NULL,
  `channelName` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_merchant_info_center`
--

DROP TABLE IF EXISTS `pay_merchant_info_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_merchant_info_center` (
  `channelId` int(11) NOT NULL COMMENT '商户ID',
  `channel` int(11) NOT NULL DEFAULT '0' COMMENT '渠道ID，0为通用渠道',
  `userLevel` int(11) NOT NULL DEFAULT '0' COMMENT '用户层级',
  `payType` int(11) NOT NULL COMMENT '支付类型',
  `payLevel` int(11) NOT NULL DEFAULT '0' COMMENT '支付档位',
  `useState` int(4) NOT NULL DEFAULT '0' COMMENT '商户是否被停用 1为普通停用 2为支付停用 ',
  PRIMARY KEY (`channelId`,`channel`,`userLevel`,`payType`,`payLevel`),
  KEY `useState` (`useState`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_type`
--

DROP TABLE IF EXISTS `pay_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_type` (
  `payname` varchar(255) NOT NULL,
  `paytype` int(11) NOT NULL,
  `paydesc` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`payname`),
  UNIQUE KEY `paytype` (`paytype`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_type_set`
--

DROP TABLE IF EXISTS `pay_type_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_type_set` (
  `channel` int(11) NOT NULL,
  `userLevel` int(11) NOT NULL,
  `payType` int(11) NOT NULL,
  `payName` varchar(20) NOT NULL,
  `rank` int(4) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `isquota` int(4) NOT NULL DEFAULT '0',
  `payList` varchar(255) NOT NULL DEFAULT '[]',
  `banner_url` varchar(255) NOT NULL,
  `selected_url` varchar(255) NOT NULL,
  `unselected_url` varchar(255) NOT NULL,
  `commonData` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`channel`,`userLevel`,`payType`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_type_set_cache`
--

DROP TABLE IF EXISTS `pay_type_set_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_type_set_cache` (
  `channel` int(11) NOT NULL,
  `userLevel` int(11) NOT NULL,
  `payType` int(11) NOT NULL,
  `payName` varchar(20) NOT NULL,
  `rank` int(4) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `isquota` int(4) NOT NULL DEFAULT '0',
  `payList` varchar(255) NOT NULL DEFAULT '[]',
  `banner_url` varchar(255) NOT NULL,
  `selected_url` varchar(255) NOT NULL,
  `unselected_url` varchar(255) NOT NULL,
  `commonData` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`channel`,`userLevel`,`payType`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payconfi`
--

DROP TABLE IF EXISTS `payconfi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payconfi` (
  `payconfiid` int(11) NOT NULL AUTO_INCREMENT,
  `versions` int(11) NOT NULL,
  `adminid` int(11) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `payconfi` text CHARACTER SET utf8,
  `userLevel` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`payconfiid`,`versions`,`userLevel`)
) ENGINE=MyISAM AUTO_INCREMENT=10205 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payshanghu`
--

DROP TABLE IF EXISTS `payshanghu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payshanghu` (
  `shanghuid` int(11) NOT NULL,
  `shangname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`shanghuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `provider_bank`
--

DROP TABLE IF EXISTS `provider_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_bank` (
  `providerid` int(11) DEFAULT NULL,
  `fxname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `number` varchar(11) CHARACTER SET utf8 DEFAULT NULL COMMENT '银行编码',
  KEY `providerid` (`providerid`),
  KEY `fxname` (`fxname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pushchannel_pay_data`
--

DROP TABLE IF EXISTS `pushchannel_pay_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pushchannel_pay_data` (
  `bigChannel` varchar(255) CHARACTER SET utf8 NOT NULL,
  `timeStamp` int(11) NOT NULL,
  `firstPayPersons` int(11) DEFAULT NULL,
  `afterFirstPayRateDay2` double(10,4) DEFAULT NULL,
  `afterFirstPayRateDay3` double(10,4) DEFAULT NULL,
  `afterFirstPayRateDay7` double(10,4) DEFAULT NULL,
  `afterFirstPayRateDay15` double(10,4) DEFAULT NULL,
  `afterFirstPayRateDay30` double(10,4) DEFAULT NULL,
  `afterFirstPayRateDay60` double(10,4) DEFAULT NULL,
  `state` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bigChannel`,`timeStamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qq`
--

DROP TABLE IF EXISTS `qq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qq` (
  `QQ` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Wecat` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Daili` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `channel` int(10) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT '',
  `whistle` varchar(255) DEFAULT NULL,
  `qrcode` varchar(500) DEFAULT NULL,
  `qrcodeurl` varchar(500) DEFAULT NULL,
  `official` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`channel`),
  UNIQUE KEY `channel` (`channel`) USING HASH
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_blob_triggers`
--

DROP TABLE IF EXISTS `qrtz_blob_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_blob_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`) USING BTREE,
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_calendars`
--

DROP TABLE IF EXISTS `qrtz_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_calendars` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_cron_triggers`
--

DROP TABLE IF EXISTS `qrtz_cron_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_cron_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(120) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_fired_triggers`
--

DROP TABLE IF EXISTS `qrtz_fired_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_fired_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `SCHED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`),
  KEY `IDX_QRTZ_FT_TRIG_INST_NAME` (`SCHED_NAME`,`INSTANCE_NAME`) USING BTREE,
  KEY `IDX_QRTZ_FT_INST_JOB_REQ_RCVRY` (`SCHED_NAME`,`INSTANCE_NAME`,`REQUESTS_RECOVERY`) USING BTREE,
  KEY `IDX_QRTZ_FT_J_G` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`) USING BTREE,
  KEY `IDX_QRTZ_FT_JG` (`SCHED_NAME`,`JOB_GROUP`) USING BTREE,
  KEY `IDX_QRTZ_FT_T_G` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`) USING BTREE,
  KEY `IDX_QRTZ_FT_TG` (`SCHED_NAME`,`TRIGGER_GROUP`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_job_details`
--

DROP TABLE IF EXISTS `qrtz_job_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_job_details` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_J_REQ_RECOVERY` (`SCHED_NAME`,`REQUESTS_RECOVERY`) USING BTREE,
  KEY `IDX_QRTZ_J_GRP` (`SCHED_NAME`,`JOB_GROUP`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_locks`
--

DROP TABLE IF EXISTS `qrtz_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_locks` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_paused_trigger_grps`
--

DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_scheduler_state`
--

DROP TABLE IF EXISTS `qrtz_scheduler_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_scheduler_state` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_simple_triggers`
--

DROP TABLE IF EXISTS `qrtz_simple_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_simple_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(10) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_simprop_triggers`
--

DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_simprop_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int(11) DEFAULT NULL,
  `INT_PROP_2` int(11) DEFAULT NULL,
  `LONG_PROP_1` bigint(20) DEFAULT NULL,
  `LONG_PROP_2` bigint(20) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrtz_triggers`
--

DROP TABLE IF EXISTS `qrtz_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtz_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_J` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`) USING BTREE,
  KEY `IDX_QRTZ_T_JG` (`SCHED_NAME`,`JOB_GROUP`) USING BTREE,
  KEY `IDX_QRTZ_T_C` (`SCHED_NAME`,`CALENDAR_NAME`) USING BTREE,
  KEY `IDX_QRTZ_T_G` (`SCHED_NAME`,`TRIGGER_GROUP`) USING BTREE,
  KEY `IDX_QRTZ_T_STATE` (`SCHED_NAME`,`TRIGGER_STATE`) USING BTREE,
  KEY `IDX_QRTZ_T_N_STATE` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`) USING BTREE,
  KEY `IDX_QRTZ_T_N_G_STATE` (`SCHED_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`) USING BTREE,
  KEY `IDX_QRTZ_T_NEXT_FIRE_TIME` (`SCHED_NAME`,`NEXT_FIRE_TIME`) USING BTREE,
  KEY `IDX_QRTZ_T_NFT_ST` (`SCHED_NAME`,`TRIGGER_STATE`,`NEXT_FIRE_TIME`) USING BTREE,
  KEY `IDX_QRTZ_T_NFT_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`) USING BTREE,
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`) USING BTREE,
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE_GRP` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_GROUP`,`TRIGGER_STATE`) USING BTREE,
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quick_pay_orders`
--

DROP TABLE IF EXISTS `quick_pay_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quick_pay_orders` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT 'id',
  `rid` int(11) NOT NULL DEFAULT '0' COMMENT 'rid',
  `orderID` varchar(32) NOT NULL DEFAULT '' COMMENT 'è®¢å•å·',
  `channel` mediumint(9) NOT NULL DEFAULT '0' COMMENT 'æ¸ é“',
  `price` float(11,2) NOT NULL DEFAULT '0.00' COMMENT 'å……å€¼é‡‘é¢',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºæ—¶é—´',
  `pay_time` int(11) NOT NULL DEFAULT '0' COMMENT 'æ”¯ä»˜æ—¶é—´',
  `state` mediumint(9) NOT NULL DEFAULT '0' COMMENT '0æ–°è®¢å•ï¼Œ1æ”¯ä»˜å¤±è´¥ï¼Œ2æ”¯ä»˜æˆåŠŸï¼Œ3å‘è´§æˆåŠŸ,4æ‹’ç»(2æš‚æ—¶ä¸ç”¨)',
  `canbesign` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'èƒ½å¦è¢«æ ‡è®° 0å¦ 1æ˜¯',
  `payer` varchar(128) NOT NULL DEFAULT '' COMMENT 'ä»˜æ¬¾äºº',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_user_id` varchar(128) DEFAULT '' COMMENT 'ä¿®æ”¹äººID',
  `update_user_name` varchar(128) DEFAULT '' COMMENT 'ä¿®æ”¹äººåç§°',
  `remark` varchar(1024) DEFAULT '' COMMENT 'ä¿®æ”¹å¤‡æ³¨',
  `bankName` varchar(64) NOT NULL DEFAULT '' COMMENT 'å…¥æ¬¾è¡Œ',
  `bankAccount` varchar(32) NOT NULL DEFAULT '' COMMENT 'å…¥æ¬¾è´¦å·',
  `rate` float(5,4) NOT NULL DEFAULT '0.0000' COMMENT 'è´¹çŽ‡',
  `ext1` varchar(128) DEFAULT NULL COMMENT 'æ‰©å±•',
  `ext2` varchar(128) DEFAULT NULL COMMENT 'æ‰©å±•2',
  `ext3` varchar(128) DEFAULT NULL COMMENT 'æ‰©å±•3',
  PRIMARY KEY (`id`,`rid`,`orderID`),
  KEY `channel` (`channel`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='å¿«æ·çº¿ä¸‹æ”¯ä»˜è®¢å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `robotmarquee`
--

DROP TABLE IF EXISTS `robotmarquee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `robotmarquee` (
  `marqueeid` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL COMMENT '2是提现,1是中奖',
  `status` int(11) DEFAULT NULL COMMENT '1是使用中，2是停用',
  `content` varchar(1000) CHARACTER SET utf8 DEFAULT NULL COMMENT '模板',
  `min` int(11) DEFAULT NULL,
  `max` int(11) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL COMMENT '房间范围',
  PRIMARY KEY (`marqueeid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_day_recharge`
--

DROP TABLE IF EXISTS `role_day_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_day_recharge` (
  `time` varchar(255) NOT NULL DEFAULT '' COMMENT 'æ—¶é—´',
  `rid` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `price` double(10,2) DEFAULT NULL,
  PRIMARY KEY (`time`,`rid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_history_kf`
--

DROP TABLE IF EXISTS `role_history_kf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_history_kf` (
  `rid` int(11) NOT NULL,
  `mess` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `identity` int(11) DEFAULT NULL COMMENT '身份  0是玩家，1是客服',
  `admin` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '管理员',
  `time` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  KEY `rid` (`rid`),
  KEY `identity` (`identity`),
  KEY `admin` (`admin`),
  KEY `time` (`time`),
  KEY `mess` (`mess`(333)),
  KEY `channel` (`channel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_login_ip`
--

DROP TABLE IF EXISTS `role_login_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_login_ip` (
  `rid` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `firsttime` int(11) DEFAULT NULL,
  `lasttime` int(11) DEFAULT NULL,
  PRIMARY KEY (`rid`,`ip`),
  KEY `rid` (`rid`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_login_oneday`
--

DROP TABLE IF EXISTS `role_login_oneday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_login_oneday` (
  `rid` int(11) NOT NULL,
  `time` varchar(255) CHARACTER SET utf8 NOT NULL,
  `channel` int(11) DEFAULT NULL,
  `generalizepid` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`rid`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_onday_tax`
--

DROP TABLE IF EXISTS `role_onday_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_onday_tax` (
  `time` varchar(255) NOT NULL,
  `rid` int(11) NOT NULL,
  `num` double DEFAULT NULL,
  PRIMARY KEY (`time`,`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_orders_bi`
--

DROP TABLE IF EXISTS `role_orders_bi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_orders_bi` (
  `orderID` varchar(60) CHARACTER SET utf8 NOT NULL,
  `operator` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`orderID`),
  KEY `orderID` (`orderID`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_register_generalize`
--

DROP TABLE IF EXISTS `role_register_generalize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_register_generalize` (
  `rid` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL COMMENT '注册时间',
  `channel` int(11) DEFAULT NULL COMMENT '渠道',
  `generalizepid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rid`),
  KEY `generalizepid` (`generalizepid`),
  KEY `time` (`time`),
  KEY `channel` (`channel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_update_kf`
--

DROP TABLE IF EXISTS `role_update_kf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_update_kf` (
  `rid` int(11) NOT NULL,
  `channel` int(11) NOT NULL COMMENT '渠道号',
  `isdispose` int(11) DEFAULT NULL COMMENT '是否需要处理 0是需要，1是不需要',
  `identity` int(11) DEFAULT NULL COMMENT '当前玩家的处理状态,0是玩家,1是客服',
  `admin` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '最后操作的客服',
  `mess` varchar(1000) CHARACTER SET utf8 DEFAULT NULL COMMENT '最后消息内容',
  `time` int(11) DEFAULT NULL COMMENT '时间',
  `lock` int(11) DEFAULT NULL COMMENT '是否上锁  0是没有，1是有',
  `lockadmin` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '锁了的客服',
  PRIMARY KEY (`rid`,`channel`),
  KEY `isdispose` (`isdispose`),
  KEY `identity` (`identity`),
  KEY `admin` (`admin`),
  KEY `time` (`time`),
  KEY `lock` (`lock`),
  KEY `lockadmin` (`lockadmin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_job`
--

DROP TABLE IF EXISTS `schedule_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_job` (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `method_name` varchar(100) DEFAULT NULL COMMENT '方法名',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `cron_expression` varchar(100) DEFAULT NULL COMMENT 'cron表达式',
  `status` tinyint(4) DEFAULT NULL COMMENT '任务状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COMMENT='定时任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_job_copy`
--

DROP TABLE IF EXISTS `schedule_job_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_job_copy` (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `method_name` varchar(100) DEFAULT NULL COMMENT '方法名',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `cron_expression` varchar(100) DEFAULT NULL COMMENT 'cron表达式',
  `status` tinyint(4) DEFAULT NULL COMMENT '任务状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COMMENT='定时任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_job_log`
--

DROP TABLE IF EXISTS `schedule_job_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_job_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务日志id',
  `job_id` bigint(20) NOT NULL COMMENT '任务id',
  `bean_name` varchar(200) DEFAULT NULL COMMENT 'spring bean名称',
  `method_name` varchar(100) DEFAULT NULL COMMENT '方法名',
  `params` varchar(2000) DEFAULT NULL COMMENT '参数',
  `status` tinyint(4) NOT NULL COMMENT '任务状态    0：成功    1：失败',
  `error` varchar(2000) DEFAULT NULL COMMENT '失败信息',
  `times` int(11) NOT NULL COMMENT '耗时(单位：毫秒)',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`log_id`),
  KEY `job_id` (`job_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=530741 DEFAULT CHARSET=utf8 COMMENT='定时任务日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sen_data`
--

DROP TABLE IF EXISTS `sen_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sen_data` (
  `ios` double NOT NULL,
  `android` double NOT NULL,
  `time` varchar(255) NOT NULL,
  `offlineid` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`offlineid`),
  UNIQUE KEY `time` (`time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `send_phone_code`
--

DROP TABLE IF EXISTS `send_phone_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `send_phone_code` (
  `className` varchar(25) NOT NULL DEFAULT '',
  `methodName` varchar(50) NOT NULL DEFAULT '',
  `useState` int(4) NOT NULL DEFAULT '1' COMMENT '0为使用中 1为未使用，必须只有一个使用中',
  `merchantName` varchar(15) NOT NULL DEFAULT '' COMMENT '平台名称',
  PRIMARY KEY (`className`,`methodName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sendmaillog`
--

DROP TABLE IF EXISTS `sendmaillog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sendmaillog` (
  `mailId` varchar(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `isDeleted` int(4) DEFAULT '0',
  `sendtype` int(4) DEFAULT NULL,
  `receiver` text,
  `sendtime` varchar(100) DEFAULT NULL,
  `isTimed` int(4) DEFAULT NULL,
  `context` varchar(25) CHARACTER SET utf8 DEFAULT '',
  `detail` varchar(255) CHARACTER SET utf8 DEFAULT '',
  `attachmentGoods` varchar(255) DEFAULT '',
  `updateTime` varchar(100) NOT NULL,
  `servermailid` int(11) DEFAULT NULL,
  `isrecall` int(255) DEFAULT NULL,
  `recalladmin` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `getattcheffect` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`mailId`),
  KEY `unionDelateAndUpdateTime` (`isDeleted`,`updateTime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_bi_address`
--

DROP TABLE IF EXISTS `server_bi_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_bi_address` (
  `urlName` varchar(125) NOT NULL,
  `urlStr` varchar(125) NOT NULL DEFAULT '',
  `urlDesc` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`urlName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_url`
--

DROP TABLE IF EXISTS `server_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_url` (
  `channel` int(11) NOT NULL,
  `channelName` varchar(20) NOT NULL DEFAULT '',
  `kefuUrl` varchar(125) NOT NULL DEFAULT '',
  `exchangeUrl` varchar(125) NOT NULL DEFAULT '',
  `pushUrl` varchar(125) NOT NULL DEFAULT '',
  `allPushUrl` varchar(125) NOT NULL DEFAULT '',
  PRIMARY KEY (`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_article`
--

DROP TABLE IF EXISTS `sys_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_article` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) DEFAULT NULL COMMENT '标题',
  `classtype` int(11) NOT NULL DEFAULT '1' COMMENT '1是新闻，2是常见问题',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1是启用，0是停用',
  `content` text,
  `time` bigint(13) DEFAULT NULL,
  PRIMARY KEY (`articleid`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_channel`
--

DROP TABLE IF EXISTS `sys_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_channel` (
  `user_id` bigint(20) NOT NULL,
  `channel` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) DEFAULT NULL COMMENT 'key',
  `value` varchar(2000) DEFAULT NULL COMMENT 'value',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态   0：隐藏   1：显示',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统配置信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_ipwhitelist`
--

DROP TABLE IF EXISTS `sys_ipwhitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_ipwhitelist` (
  `ipid` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `username` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ipid`),
  UNIQUE KEY `ip` (`ip`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5036 DEFAULT CHARSET=utf8 COMMENT='系统日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父菜单ID，一级菜单为0',
  `name` varchar(50) DEFAULT NULL COMMENT '菜单名称',
  `url` varchar(200) DEFAULT NULL COMMENT '菜单URL',
  `perms` varchar(500) DEFAULT NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` int(11) DEFAULT NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(50) DEFAULT NULL COMMENT '菜单图标',
  `order_num` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`menu_id`),
  KEY `parent_id` (`parent_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=421 DEFAULT CHARSET=utf8 COMMENT='菜单管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_oss`
--

DROP TABLE IF EXISTS `sys_oss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_oss` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL COMMENT 'URL地址',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文件上传';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COMMENT='角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role_menu`
--

DROP TABLE IF EXISTS `sys_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `menu_id` bigint(20) DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78328 DEFAULT CHARSET=utf8 COMMENT='角色与菜单对应关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) DEFAULT NULL COMMENT '密码',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(100) DEFAULT NULL COMMENT '手机号',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态  0：禁用   1：正常',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `seephone` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8 COMMENT='系统用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user_provider`
--

DROP TABLE IF EXISTS `sys_user_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user_provider` (
  `user_name` varchar(255) NOT NULL,
  `providerid` int(11) NOT NULL,
  PRIMARY KEY (`user_name`,`providerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=660 DEFAULT CHARSET=utf8 COMMENT='用户与角色对应关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_token`
--

DROP TABLE IF EXISTS `tb_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_token` (
  `user_id` bigint(20) NOT NULL,
  `token` varchar(100) NOT NULL COMMENT 'token',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `token` (`token`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户Token';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_user`
--

DROP TABLE IF EXISTS `tb_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `mobile` varchar(20) NOT NULL COMMENT '手机号',
  `password` varchar(64) DEFAULT NULL COMMENT '密码',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `type_channel`
--

DROP TABLE IF EXISTS `type_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_channel` (
  `typeOfChannel` int(4) NOT NULL COMMENT '存储类型 1-公告 2-跑马灯 3-支付',
  `channel` int(11) NOT NULL,
  `channelName` varchar(128) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`typeOfChannel`,`channel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_level`
--

DROP TABLE IF EXISTS `user_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_level` (
  `rid` int(11) NOT NULL,
  `userLevel` int(4) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `userLevel` (`userLevel`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_level_info`
--

DROP TABLE IF EXISTS `user_level_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_level_info` (
  `userLevel` int(4) NOT NULL DEFAULT '0',
  `userLevelName` varchar(40) CHARACTER SET utf8 DEFAULT '' COMMENT '用户层级名称',
  `userLevelDesc` varchar(128) CHARACTER SET utf8 DEFAULT '' COMMENT '用户层级描述，默认空字符串',
  `totalPayMin` int(11) DEFAULT NULL,
  `totalPayMax` int(11) DEFAULT NULL COMMENT '线上总充值范围',
  `totalPayTimesMin` int(11) DEFAULT NULL,
  `totalPayTimesMax` int(11) DEFAULT NULL COMMENT '线上总充值次数范围',
  `totalChipInMin` int(11) DEFAULT NULL COMMENT '总打码量范围',
  `totalChipInMax` int(11) DEFAULT NULL,
  `totalCashExportMin` int(11) DEFAULT NULL COMMENT '总提现范围',
  `totalCashExportMax` int(11) DEFAULT NULL,
  `totalCashExportTimesMin` int(11) DEFAULT NULL COMMENT '总提现次数范围',
  `totalCashExportTimesMax` int(11) DEFAULT NULL,
  `mostPayOneTimeMin` int(11) DEFAULT NULL COMMENT '单次最大提现范围',
  `mostPayOneTimeMax` int(11) DEFAULT NULL,
  `onlineTimeMin` int(11) DEFAULT NULL,
  `onlineTimeMax` int(11) DEFAULT NULL,
  `createTimeMin` int(11) DEFAULT NULL,
  `createTimeMax` int(11) DEFAULT NULL,
  `playedTimeMin` int(11) DEFAULT NULL,
  `playedTimeMax` int(11) DEFAULT NULL,
  `playedGameNumMin` int(11) DEFAULT NULL,
  `playedGameNumMax` int(11) DEFAULT NULL,
  `updateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`userLevel`),
  KEY `userLevel` (`userLevel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_level_whitelist`
--

DROP TABLE IF EXISTS `user_level_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_level_whitelist` (
  `rid` int(11) NOT NULL,
  `userLevel` int(4) unsigned zerofill NOT NULL DEFAULT '0000',
  `updateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  KEY `userLevel` (`userLevel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `visiturljson`
--

DROP TABLE IF EXISTS `visiturljson`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visiturljson` (
  `id` int(11) NOT NULL,
  `visitjson` varchar(2000) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `withdraw_deposit_provider`
--

DROP TABLE IF EXISTS `withdraw_deposit_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_deposit_provider` (
  `providerid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商户id',
  `provideraccount` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '商户号',
  `providerpassword` varchar(2600) CHARACTER SET utf8 DEFAULT NULL COMMENT '商户密码',
  `publickey` varchar(2600) DEFAULT NULL COMMENT '公钥',
  `providerpublickey` varchar(2600) CHARACTER SET utf8 DEFAULT NULL COMMENT '商户公钥(博顺有使用)',
  `paykey` varchar(2600) DEFAULT NULL,
  `encipherment` int(11) NOT NULL COMMENT '加密类型1是MD5',
  `apiurl` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '接口地址',
  `inquireurl` varchar(255) DEFAULT NULL,
  `informurl` varchar(255) DEFAULT NULL,
  `providtype` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '回调地址',
  `providname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `isinform` int(11) DEFAULT NULL COMMENT '是否有回调 0是没有，1是有',
  `using` int(11) NOT NULL DEFAULT '0' COMMENT '0是启用',
  `type` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`providerid`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `withdraw_score`
--

DROP TABLE IF EXISTS `withdraw_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_score` (
  `type` tinyint(4) NOT NULL,
  `deposit` double(14,2) DEFAULT NULL COMMENT '存款',
  `depositzb` double(255,0) DEFAULT NULL COMMENT '存款占比',
  `yingkuib` double(255,0) DEFAULT NULL COMMENT '盈亏比',
  `yingkuizb` double(255,0) DEFAULT NULL COMMENT '盈亏比占比',
  `damazb` double DEFAULT NULL COMMENT '打码占比',
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `withdrawal_grading`
--

DROP TABLE IF EXISTS `withdrawal_grading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdrawal_grading` (
  `type` tinyint(1) NOT NULL,
  `max` double(10,0) DEFAULT NULL,
  `min` double(10,0) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zcjb_vip`
--

DROP TABLE IF EXISTS `zcjb_vip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zcjb_vip` (
  `account` varchar(112) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `payFrom` int(11) NOT NULL DEFAULT '0',
  `vipRank` int(4) NOT NULL DEFAULT '0',
  `des` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 19:18:19
