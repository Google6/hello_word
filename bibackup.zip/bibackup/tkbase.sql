-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: tkbase
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `generalize`
--

DROP TABLE IF EXISTS `generalize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generalize` (
  `generalizeid` int(11) NOT NULL AUTO_INCREMENT,
  `generalizepid` varchar(255) DEFAULT NULL,
  `androidurl` varchar(255) DEFAULT NULL,
  `iosurl` varchar(255) DEFAULT NULL,
  `generalizename` varchar(30) DEFAULT NULL,
  `www` varchar(255) DEFAULT NULL COMMENT '推广网站备注',
  `channle` int(11) DEFAULT NULL,
  `sys_id` int(11) DEFAULT '1',
  `min_pic` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`generalizeid`)
) ENGINE=InnoDB AUTO_INCREMENT=11301351 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_agent_num`
--

DROP TABLE IF EXISTS `vc_agent_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_agent_num` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `duty_num` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=104823 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_ali_bank`
--

DROP TABLE IF EXISTS `vc_ali_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_ali_bank` (
  `sys_id` int(11) DEFAULT NULL,
  `ali_Account` varchar(100) DEFAULT NULL COMMENT '支付宝账户',
  `real_name` varchar(100) DEFAULT NULL COMMENT '支付宝真实姓名',
  `card_account` varchar(100) DEFAULT NULL COMMENT '银行卡账号',
  `bank_name` varchar(100) DEFAULT NULL COMMENT '持卡人姓名',
  `id_Card` varchar(100) DEFAULT NULL COMMENT '身份证号码',
  `bank_type` varchar(20) DEFAULT '-1' COMMENT '选择开户行',
  `province` varchar(100) DEFAULT NULL COMMENT '开户行所在省份',
  `city` varchar(100) DEFAULT NULL COMMENT '开户行所在城市',
  `bank_password` varchar(100) DEFAULT NULL,
  `bank_branch` varchar(100) DEFAULT NULL,
  `aliBind` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_code_log`
--

DROP TABLE IF EXISTS `vc_code_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_code_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `tx_count` varchar(100) DEFAULT NULL,
  `yl_count` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `info` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=942232 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_comment`
--

DROP TABLE IF EXISTS `vc_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL COMMENT '标题',
  `comment` varchar(500) DEFAULT NULL COMMENT '公告内容',
  `add_time` datetime DEFAULT NULL COMMENT '添加时间',
  `agent_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_countlog`
--

DROP TABLE IF EXISTS `vc_countlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_countlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tx_count` varchar(100) DEFAULT NULL,
  `yl_count` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `info` varchar(500) DEFAULT NULL,
  `check_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15003 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_day`
--

DROP TABLE IF EXISTS `vc_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8627 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_day_num`
--

DROP TABLE IF EXISTS `vc_day_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_day_num` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `sys_id` int(11) DEFAULT NULL,
  `sys_user` varchar(100) DEFAULT NULL,
  `sys_level` varchar(11) DEFAULT NULL,
  `proportions` varchar(100) DEFAULT NULL,
  `gent_nick` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `generalizeid` int(11) DEFAULT NULL,
  `balance` varchar(100) DEFAULT NULL,
  `income1` varchar(100) DEFAULT NULL,
  `income2` varchar(100) DEFAULT NULL,
  `income3` varchar(100) DEFAULT NULL,
  `income4` varchar(100) DEFAULT NULL,
  `income5` varchar(100) DEFAULT NULL,
  `sf_balance` varchar(100) DEFAULT NULL,
  `sf_income1` varchar(100) DEFAULT NULL,
  `sf_income2` varchar(100) DEFAULT NULL,
  `sf_income3` varchar(100) DEFAULT NULL,
  `sf_income4` varchar(100) DEFAULT NULL,
  `sf_income5` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=814 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_domain`
--

DROP TABLE IF EXISTS `vc_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_parm` varchar(300) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_gamenum_log`
--

DROP TABLE IF EXISTS `vc_gamenum_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_gamenum_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` int(11) DEFAULT NULL,
  `game_num` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `info` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12709 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_income`
--

DROP TABLE IF EXISTS `vc_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_income` (
  `income_id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` int(11) DEFAULT NULL,
  `income_number` decimal(12,2) DEFAULT NULL,
  `game_id` int(11) DEFAULT NULL,
  `agent_income` varchar(100) DEFAULT NULL COMMENT '税收',
  `create_time` datetime DEFAULT NULL,
  `game_name` varchar(100) DEFAULT NULL,
  `game_type` int(2) DEFAULT NULL,
  `channel_name` varchar(100) DEFAULT NULL COMMENT '渠道',
  PRIMARY KEY (`income_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log`
--

DROP TABLE IF EXISTS `vc_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT '',
  `login_time` datetime DEFAULT NULL,
  `login_ip` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=322750 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log_down`
--

DROP TABLE IF EXISTS `vc_log_down`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log_down` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(255) DEFAULT '',
  `login_time` datetime DEFAULT NULL,
  `login_ip` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3491 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log_money`
--

DROP TABLE IF EXISTS `vc_log_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_id` varchar(255) DEFAULT '',
  `login_time` date DEFAULT NULL,
  `all_balance` varchar(255) DEFAULT NULL,
  `tax_num` varchar(255) DEFAULT '',
  `login_ip` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=55226 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_log_rid`
--

DROP TABLE IF EXISTS `vc_log_rid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_log_rid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT '',
  `agent_name` varchar(255) DEFAULT '',
  `rid` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `generalizeid` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=225 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_opto`
--

DROP TABLE IF EXISTS `vc_opto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_opto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `opto` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `opt_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1733 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_pomotion`
--

DROP TABLE IF EXISTS `vc_pomotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_pomotion` (
  `promotion_id` int(11) NOT NULL AUTO_INCREMENT,
  `code_id` int(11) DEFAULT NULL,
  `promotion_address` varchar(100) DEFAULT NULL,
  `promotion_name` varchar(100) DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_qrcode`
--

DROP TABLE IF EXISTS `vc_qrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_qrcode` (
  `code_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) DEFAULT NULL,
  `spread_url` varchar(500) DEFAULT NULL,
  `min_pic` varchar(500) DEFAULT NULL,
  `max_pic` varchar(500) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`code_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_rid`
--

DROP TABLE IF EXISTS `vc_rid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_rid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_user` varchar(20) DEFAULT NULL,
  `sys_level` int(4) DEFAULT NULL,
  `proportions` varchar(100) DEFAULT NULL,
  `creat_time` datetime DEFAULT NULL,
  `rid` int(11) DEFAULT '0',
  `sys_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=328422 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_rid_code`
--

DROP TABLE IF EXISTS `vc_rid_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_rid_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`) USING BTREE,
  KEY `url` (`url`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=585 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_setting`
--

DROP TABLE IF EXISTS `vc_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_type` int(11) DEFAULT '1',
  `key_name` varchar(255) DEFAULT '',
  `key_url` varchar(255) DEFAULT '',
  `order_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_statistics`
--

DROP TABLE IF EXISTS `vc_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_statistics` (
  `statistics_id` int(11) NOT NULL AUTO_INCREMENT,
  `charge_number` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `duty_number` char(100) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `reflect_number` int(11) DEFAULT NULL,
  `register_number` int(11) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`statistics_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_statistics_num`
--

DROP TABLE IF EXISTS `vc_statistics_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_statistics_num` (
  `statistics_id` int(11) NOT NULL AUTO_INCREMENT,
  `charge_number` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `duty_number` char(100) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `reflect_number` int(11) DEFAULT NULL,
  `register_number` int(11) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `sys_user` char(100) DEFAULT NULL,
  `sys_level` int(11) DEFAULT NULL,
  `generalizeid` int(11) DEFAULT NULL,
  `proportions` char(100) DEFAULT NULL,
  `gent_nick` char(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `balance` varchar(100) DEFAULT NULL,
  `sf_balance` varchar(100) DEFAULT NULL,
  `sf_income1` varchar(100) DEFAULT NULL,
  `income1` varchar(100) DEFAULT NULL,
  `income2` varchar(100) DEFAULT NULL,
  `income3` varchar(100) DEFAULT NULL,
  `income4` varchar(100) DEFAULT NULL,
  `income5` varchar(100) DEFAULT NULL,
  `sf_income2` varchar(100) DEFAULT NULL,
  `sf_income3` varchar(100) DEFAULT NULL,
  `sf_income4` varchar(100) DEFAULT NULL,
  `income6` varchar(100) DEFAULT NULL,
  `income7` varchar(100) DEFAULT NULL,
  `income8` varchar(100) DEFAULT NULL,
  `income9` varchar(100) DEFAULT NULL,
  `income10` varchar(100) DEFAULT NULL,
  `income11` varchar(100) DEFAULT NULL,
  `sf_income5` varchar(100) DEFAULT NULL,
  `sf_income6` varchar(100) DEFAULT NULL,
  `sf_income7` varchar(100) DEFAULT NULL,
  `sf_income8` varchar(100) DEFAULT NULL,
  `sf_income9` varchar(100) DEFAULT NULL,
  `sf_income10` varchar(100) DEFAULT NULL,
  `sf_income11` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`statistics_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3166456 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_statistics_num1`
--

DROP TABLE IF EXISTS `vc_statistics_num1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_statistics_num1` (
  `statistics_id` int(11) NOT NULL AUTO_INCREMENT,
  `charge_number` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `duty_number` char(100) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `reflect_number` int(11) DEFAULT NULL,
  `register_number` int(11) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `sys_user` char(100) DEFAULT NULL,
  `sys_level` int(11) DEFAULT NULL,
  `generalizeid` int(11) DEFAULT NULL,
  `proportions` char(100) DEFAULT NULL,
  `gent_nick` char(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `balance` varchar(100) DEFAULT NULL,
  `sf_balance` varchar(100) DEFAULT NULL,
  `sf_income1` varchar(100) DEFAULT NULL,
  `income1` varchar(100) DEFAULT NULL,
  `income2` varchar(100) DEFAULT NULL,
  `income3` varchar(100) DEFAULT NULL,
  `income4` varchar(100) DEFAULT NULL,
  `income5` varchar(100) DEFAULT NULL,
  `income6` varchar(100) DEFAULT NULL,
  `income7` varchar(100) DEFAULT NULL,
  `income8` varchar(100) DEFAULT NULL,
  `income9` varchar(100) DEFAULT NULL,
  `income10` varchar(100) DEFAULT NULL,
  `income11` varchar(100) DEFAULT NULL,
  `sf_income2` varchar(100) DEFAULT NULL,
  `sf_income3` varchar(100) DEFAULT NULL,
  `sf_income4` varchar(100) DEFAULT NULL,
  `sf_income5` varchar(100) DEFAULT NULL,
  `sf_income6` varchar(100) DEFAULT NULL,
  `sf_income7` varchar(100) DEFAULT NULL,
  `sf_income8` varchar(100) DEFAULT NULL,
  `sf_income9` varchar(100) DEFAULT NULL,
  `sf_income10` varchar(100) DEFAULT NULL,
  `sf_income11` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`statistics_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1361287 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_sys`
--

DROP TABLE IF EXISTS `vc_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_user` varchar(20) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `sys_password` varchar(100) DEFAULT NULL,
  `sys_level` int(4) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(30) DEFAULT NULL,
  `privilege` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `gent_nick` varchar(100) DEFAULT NULL,
  `proportions` varchar(100) DEFAULT NULL,
  `is_ip` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `balance` varchar(100) DEFAULT '0',
  `login_time` datetime DEFAULT NULL,
  `info` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `creat_time` datetime DEFAULT NULL,
  `all_balance` varchar(100) DEFAULT '0',
  `rid` int(11) DEFAULT '0',
  `tk_balance` varchar(100) DEFAULT NULL,
  `game_num` varchar(100) DEFAULT NULL,
  `rid_ip` varchar(255) NOT NULL DEFAULT '0',
  `bank_password` varchar(100) DEFAULT NULL,
  `new_pass` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11301310 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_template`
--

DROP TABLE IF EXISTS `vc_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_template` (
  `template_Id` int(11) NOT NULL AUTO_INCREMENT,
  `template_title` varchar(100) DEFAULT NULL,
  `template_introduce` varchar(100) DEFAULT NULL,
  `template_url` varchar(100) DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`template_Id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_week`
--

DROP TABLE IF EXISTS `vc_week`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_week` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `info` varchar(1000) DEFAULT NULL,
  `week_info` varchar(100) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `tax_num` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=87432 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_week1`
--

DROP TABLE IF EXISTS `vc_week1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_week1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `info` varchar(1000) DEFAULT NULL,
  `week_info` varchar(100) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `tax_num` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27248 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vc_week_num`
--

DROP TABLE IF EXISTS `vc_week_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vc_week_num` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys_level` int(11) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `num` varchar(100) DEFAULT NULL,
  `sys_id` int(11) DEFAULT NULL,
  `sys_user` varchar(100) DEFAULT '0',
  `proportions` varchar(20) DEFAULT NULL,
  `week_info` varchar(100) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `tax_num` varchar(100) DEFAULT NULL,
  `new_proportions` varchar(20) DEFAULT NULL,
  `status` int(2) DEFAULT '1',
  `info` varchar(1000) DEFAULT NULL,
  `agentNum` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12757 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 19:18:20
