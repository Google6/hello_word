-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: paymanager
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `merchantmanager`
--

DROP TABLE IF EXISTS `merchantmanager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchantmanager` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `channelId` int(8) unsigned zerofill NOT NULL,
  `merchantId` varchar(255) NOT NULL DEFAULT '',
  `notifyurl` varchar(255) NOT NULL DEFAULT '',
  `hrefbackurl` varchar(255) NOT NULL DEFAULT '',
  `apiurl` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `Upperlimit` int(8) unsigned zerofill NOT NULL,
  `Lowerlimit` int(8) NOT NULL,
  `interval` int(3) unsigned zerofill NOT NULL,
  `level` int(3) unsigned zerofill NOT NULL,
  `privateykey` text NOT NULL,
  `publickey` text NOT NULL,
  `signTpye` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `index` (`channelId`) USING HASH,
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paymapper`
--

DROP TABLE IF EXISTS `paymapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymapper` (
  `payname` varchar(255) NOT NULL DEFAULT '',
  `paytype` int(8) unsigned zerofill NOT NULL,
  `channels` text COMMENT 'æ”¯æŒæ”¯ä»˜æ¸ é“',
  `userLevel` int(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`paytype`,`userLevel`),
  KEY `payname` (`payname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payorder`
--

DROP TABLE IF EXISTS `payorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channelId` int(8) NOT NULL,
  `orderId` varchar(225) NOT NULL DEFAULT '',
  `paytype` int(8) NOT NULL,
  `price` int(8) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23160 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payworkcfg`
--

DROP TABLE IF EXISTS `payworkcfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payworkcfg` (
  `userLevel` int(11) NOT NULL,
  `paycfg` text,
  PRIMARY KEY (`userLevel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recordparm`
--

DROP TABLE IF EXISTS `recordparm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recordparm` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `payname` varchar(255) NOT NULL DEFAULT '',
  `price` varchar(255) NOT NULL DEFAULT '',
  `payorder` varchar(255) NOT NULL DEFAULT '',
  `oderDescr` varchar(255) NOT NULL DEFAULT '',
  `cardNo` varchar(255) NOT NULL DEFAULT '',
  `cardPsw` varchar(255) NOT NULL DEFAULT '',
  `userlevel` varchar(255) NOT NULL DEFAULT '',
  `updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `index` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=110404 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 19:18:20
