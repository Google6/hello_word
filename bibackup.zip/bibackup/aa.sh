#!/bin/bash
mysqldump -h localhost -uroot -pccm123  -d bi > bi.sql
mysqldump -h localhost -uroot -pccm123  -d fxbase > fxbase.sql
mysqldump -h localhost -uroot -pccm123  -d gateway > gateway.sql
mysqldump -h localhost -uroot -pccm123  -d paymanager > paymanager.sql
mysqldump -h localhost -uroot -pccm123  -d tkbase > tkbase.sql
mysqldump -h localhost -uroot -pccm123  -d weixin > weixin.sql



